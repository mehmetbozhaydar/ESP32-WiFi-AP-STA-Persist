# Wi-Fi  Station Example

This project is designed to develop a Wi-Fi client application based on ESP32. The application connects to a Wi-Fi network and sends data in JSON format to a server. The data includes the Wi-Fi SSID and password. A TCP connection is established using ESP32's Wi-Fi capabilities, and the JSON data is transmitted to the server.
## Libraries Used

    FreeRTOS: Used for task management and event groups.
    ESP-IDF Wi-Fi: Provides the necessary APIs to use the ESP32's Wi-Fi capabilities.
    cJSON: Used for creating and manipulating JSON data structures.
    LWIP: Handles networking protocols (TCP/IP).

## Hardware Requirements

    ESP32 module (preferably ESP32 C6 or esp32 wroom)
    Wi-Fi Network: The application will connect to a Wi-Fi network and send data over the internet.

## Configuration

    Wi-Fi SSID: ESP32_C6_AP
    Wi-Fi Password: 12345678
    Server IP: 192.168.1.1
    Server Port: 3333

Setup Instructions

    Configure the Project:
        Update the wifi_config.h file in the project directory with your Wi-Fi SSID and password.
        Modify the SERVER_IP and SERVER_PORT macros to match your server's IP address and port.

    Build and Flash the Project:
        Connect your ESP32 to your computer and use the ESP-IDF environment to build and flash the project.
        Use the following commands to build and upload the project:

        idf.py build
        idf.py -p (your_port_number) flash

    Running the Application:
        Upon startup, the ESP32 will attempt to connect to the Wi-Fi network and send the JSON data to the server.
        If the connection is successful, the SSID and password will be transmitted as JSON.

    Connection Status and Error Handling:
        If the connection is successful, JSON data will be sent to the server.
        If the connection fails, the application will attempt to reconnect up to a maximum of 8 retries.

Features

    Wi-Fi Connection: The ESP32 module connects to a Wi-Fi network.
    JSON Data Transmission: The Wi-Fi SSID and password are sent to the server in JSON format.
    Event-Driven Design: The Wi-Fi connection status is managed using ESP32's event system.

Troubleshooting

    Connection Failure: Ensure that the Wi-Fi SSID and password are correct, and that the server IP address is accessible.
    JSON Data Not Sent: Check if the device successfully connects to the server, and verify your network connection.


