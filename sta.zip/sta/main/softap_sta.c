#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_mac.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif_net_stack.h"
#include "esp_netif.h"
#include "nvs_flash.h"
#include "lwip/inet.h"
#include "lwip/netdb.h"
#include "lwip/sockets.h"
#include "cJSON.h"

/* Wi-Fi bağlantı ve yapılandırma ayarları */
#define EXAMPLE_ESP_WIFI_STA_SSID           "ESP32_C6_AP"
#define EXAMPLE_ESP_WIFI_STA_PASSWD         "12345678"
#define EXAMPLE_ESP_MAXIMUM_RETRY           8
#define SERVER_IP                           "192.168.1.1"   // Sunucu IP adresi
#define SERVER_PORT                         3333              // Sunucu Portu

/* Wi-Fi event grup bitleri */
#define WIFI_CONNECTED_BIT BIT0
#define WIFI_FAIL_BIT      BIT1

static const char *TAG_STA = "WiFi Sta";
static int s_retry_num = 0;
static EventGroupHandle_t s_wifi_event_group;

static void wifi_event_handler(void *arg, esp_event_base_t event_base,
                               int32_t event_id, void *event_data)
{
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
        ESP_LOGI(TAG_STA, "Station started");
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *event = (ip_event_got_ip_t *) event_data;
        ESP_LOGI(TAG_STA, "Got IP:" IPSTR, IP2STR(&event->ip_info.ip));
        s_retry_num = 0;
        xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        if (s_retry_num < EXAMPLE_ESP_MAXIMUM_RETRY) {
            esp_wifi_connect();
            s_retry_num++;
            ESP_LOGI(TAG_STA, "Retrying connection to the AP...");
        } else {
            xEventGroupSetBits(s_wifi_event_group, WIFI_FAIL_BIT);
        }
    }
}

esp_netif_t *wifi_init_sta(void)
{
    esp_netif_t *esp_netif_sta = esp_netif_create_default_wifi_sta();

    wifi_config_t wifi_sta_config = {
        .sta = {
            .ssid = EXAMPLE_ESP_WIFI_STA_SSID,
            .password = EXAMPLE_ESP_WIFI_STA_PASSWD,
            .scan_method = WIFI_ALL_CHANNEL_SCAN,
            .failure_retry_cnt = EXAMPLE_ESP_MAXIMUM_RETRY,
            .threshold.authmode = WIFI_AUTH_WPA2_PSK,
        },
    };

    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_sta_config));
    ESP_LOGI(TAG_STA, "Wi-Fi Station Initialized.");

    return esp_netif_sta;
}

void send_json_data(void)
{
    // Sunucuya bağlan
    struct sockaddr_in server_addr;
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        ESP_LOGE(TAG_STA, "Soket oluşturulamadı!");
        return;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    // Sunucuya bağlan
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        ESP_LOGE(TAG_STA, "Sunucuya bağlanılamadı!");
        close(sock);
        return;
    }

    // İlk olarak Wi-Fi adını gönder
    cJSON *wifi_name_json = cJSON_CreateObject();
    cJSON_AddStringToObject(wifi_name_json, "wifi_name", "DESKTOP-B");
    char *wifi_name_str = cJSON_Print(wifi_name_json);
    if (send(sock, wifi_name_str, strlen(wifi_name_str), 0) < 0) {
        ESP_LOGE(TAG_STA, "Wi-Fi adı gönderilemedi!");
        cJSON_Delete(wifi_name_json);
        free(wifi_name_str);
        close(sock);
        return;
    }
    ESP_LOGI(TAG_STA, "Wi-Fi adı gönderildi: %s", wifi_name_str);

    // Kaynakları temizle
    cJSON_Delete(wifi_name_json);
    free(wifi_name_str);

    // Şifreyi göndermeden önce kısa bir gecikme ekleyebilirsiniz (isteğe bağlı)
    vTaskDelay(pdMS_TO_TICKS(100)); // 100 ms gecikme

    // Şifreyi gönder
    cJSON *wifi_password_json = cJSON_CreateObject();
    cJSON_AddStringToObject(wifi_password_json, "wifi_password", "12345678");
    char *wifi_password_str = cJSON_Print(wifi_password_json);
    if (send(sock, wifi_password_str, strlen(wifi_password_str), 0) < 0) {
        ESP_LOGE(TAG_STA, "Wi-Fi şifresi gönderilemedi!");
        cJSON_Delete(wifi_password_json);
        free(wifi_password_str);
        close(sock);
        return;
    }
    ESP_LOGI(TAG_STA, "Wi-Fi şifresi gönderildi: %s", wifi_password_str);

    // Kaynakları temizle
    cJSON_Delete(wifi_password_json);
    free(wifi_password_str);

    // Soketi kapat
    close(sock);
    //esp_wifi_stop();

}


void app_main(void)
{
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    // Initialize NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    // Event group oluştur
    s_wifi_event_group = xEventGroupCreate();

    // Wi-Fi event handler'ı kaydet
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT,
                    ESP_EVENT_ANY_ID,
                    &wifi_event_handler,
                    NULL,
                    NULL));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT,
                    IP_EVENT_STA_GOT_IP,
                    &wifi_event_handler,
                    NULL,
                    NULL));

    // Wi-Fi başlat
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));  // Only STA mode (Station mode)

    // Wi-Fi bağlantısını başlat
    wifi_init_sta();

    // Wi-Fi başlat
    ESP_ERROR_CHECK(esp_wifi_start());

    // Bağlantıyı bekle
    EventBits_t bits = xEventGroupWaitBits(s_wifi_event_group,
                                           WIFI_CONNECTED_BIT | WIFI_FAIL_BIT,
                                           pdFALSE,
                                           pdFALSE,
                                           portMAX_DELAY);  
   ESP_LOGI(TAG_STA, "Wi-Fi STA mode started, SSID: %s", EXAMPLE_ESP_WIFI_STA_SSID);

    // Bağlantı durumunu kontrol et
    if (bits & WIFI_CONNECTED_BIT) {
        ESP_LOGI(TAG_STA, "Bağlantı başarılı, JSON verisi gönderiliyor...");
        send_json_data();
    } else if (bits & WIFI_FAIL_BIT) {
        ESP_LOGI(TAG_STA, "Bağlantı başarısız oldu");
    } else {
        ESP_LOGE(TAG_STA, "Beklenmedik bir hata oluştu.");
    }
}
